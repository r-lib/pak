library(testthat)
library(foobar)

test_check("foobar")
